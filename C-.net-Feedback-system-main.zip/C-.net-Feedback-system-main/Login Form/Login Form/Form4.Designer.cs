﻿
namespace Login_Form
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.bunifuCustomLabel2 = new ns1.BunifuCustomLabel();
            this.bunifuFlatButton2 = new ns1.BunifuFlatButton();
            this.inputCustomerAddress = new ns1.BunifuMetroTextbox();
            this.inputCustomerName = new ns1.BunifuMetroTextbox();
            this.inputCustomerEmail = new ns1.BunifuMetroTextbox();
            this.inputCustomerNumber = new ns1.BunifuMetroTextbox();
            this.c = new ns1.BunifuCustomLabel();
            this.bunifuImageButton1 = new ns1.BunifuImageButton();
            this.bunifuFlatButton1 = new ns1.BunifuFlatButton();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.excellent1 = new System.Windows.Forms.RadioButton();
            this.good1 = new System.Windows.Forms.RadioButton();
            this.av1 = new System.Windows.Forms.RadioButton();
            this.dis1 = new System.Windows.Forms.RadioButton();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.excellent2 = new System.Windows.Forms.RadioButton();
            this.good2 = new System.Windows.Forms.RadioButton();
            this.average2 = new System.Windows.Forms.RadioButton();
            this.dis2 = new System.Windows.Forms.RadioButton();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.excellent3 = new System.Windows.Forms.RadioButton();
            this.good3 = new System.Windows.Forms.RadioButton();
            this.satisfied3 = new System.Windows.Forms.RadioButton();
            this.dis3 = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(590, 36);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(46, 16);
            this.bunifuCustomLabel2.TabIndex = 20;
            this.bunifuCustomLabel2.Text = "Admin";
            this.bunifuCustomLabel2.Click += new System.EventHandler(this.bunifuCustomLabel2_Click);
            // 
            // bunifuFlatButton2
            // 
            this.bunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton2.BorderRadius = 0;
            this.bunifuFlatButton2.ButtonText = "Add Feedback";
            this.bunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton2.Iconimage")));
            this.bunifuFlatButton2.Iconimage_right = null;
            this.bunifuFlatButton2.Iconimage_right_Selected = null;
            this.bunifuFlatButton2.Iconimage_Selected = null;
            this.bunifuFlatButton2.IconMarginLeft = 0;
            this.bunifuFlatButton2.IconMarginRight = 0;
            this.bunifuFlatButton2.IconRightVisible = true;
            this.bunifuFlatButton2.IconRightZoom = 0D;
            this.bunifuFlatButton2.IconVisible = true;
            this.bunifuFlatButton2.IconZoom = 90D;
            this.bunifuFlatButton2.IsTab = false;
            this.bunifuFlatButton2.Location = new System.Drawing.Point(724, 836);
            this.bunifuFlatButton2.Margin = new System.Windows.Forms.Padding(6);
            this.bunifuFlatButton2.Name = "bunifuFlatButton2";
            this.bunifuFlatButton2.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton2.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton2.selected = false;
            this.bunifuFlatButton2.Size = new System.Drawing.Size(442, 89);
            this.bunifuFlatButton2.TabIndex = 27;
            this.bunifuFlatButton2.Text = "Add Feedback";
            this.bunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton2.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton2.Click += new System.EventHandler(this.bunifuFlatButton2_Click);
            // 
            // inputCustomerAddress
            // 
            this.inputCustomerAddress.BorderColorFocused = System.Drawing.Color.White;
            this.inputCustomerAddress.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.inputCustomerAddress.BorderColorMouseHover = System.Drawing.Color.LightSteelBlue;
            this.inputCustomerAddress.BorderThickness = 3;
            this.inputCustomerAddress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.inputCustomerAddress.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.inputCustomerAddress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.inputCustomerAddress.isPassword = false;
            this.inputCustomerAddress.Location = new System.Drawing.Point(57, 142);
            this.inputCustomerAddress.Margin = new System.Windows.Forms.Padding(4);
            this.inputCustomerAddress.Name = "inputCustomerAddress";
            this.inputCustomerAddress.Size = new System.Drawing.Size(280, 44);
            this.inputCustomerAddress.TabIndex = 25;
            this.inputCustomerAddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // inputCustomerName
            // 
            this.inputCustomerName.BorderColorFocused = System.Drawing.Color.White;
            this.inputCustomerName.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.inputCustomerName.BorderColorMouseHover = System.Drawing.Color.LightSteelBlue;
            this.inputCustomerName.BorderThickness = 3;
            this.inputCustomerName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.inputCustomerName.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.inputCustomerName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.inputCustomerName.isPassword = false;
            this.inputCustomerName.Location = new System.Drawing.Point(57, 77);
            this.inputCustomerName.Margin = new System.Windows.Forms.Padding(4);
            this.inputCustomerName.Name = "inputCustomerName";
            this.inputCustomerName.Size = new System.Drawing.Size(280, 44);
            this.inputCustomerName.TabIndex = 23;
            this.inputCustomerName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // inputCustomerEmail
            // 
            this.inputCustomerEmail.BorderColorFocused = System.Drawing.Color.White;
            this.inputCustomerEmail.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.inputCustomerEmail.BorderColorMouseHover = System.Drawing.Color.LightSteelBlue;
            this.inputCustomerEmail.BorderThickness = 3;
            this.inputCustomerEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.inputCustomerEmail.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.inputCustomerEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.inputCustomerEmail.isPassword = false;
            this.inputCustomerEmail.Location = new System.Drawing.Point(356, 142);
            this.inputCustomerEmail.Margin = new System.Windows.Forms.Padding(4);
            this.inputCustomerEmail.Name = "inputCustomerEmail";
            this.inputCustomerEmail.Size = new System.Drawing.Size(280, 44);
            this.inputCustomerEmail.TabIndex = 26;
            this.inputCustomerEmail.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // inputCustomerNumber
            // 
            this.inputCustomerNumber.BorderColorFocused = System.Drawing.Color.White;
            this.inputCustomerNumber.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.inputCustomerNumber.BorderColorMouseHover = System.Drawing.Color.LightSteelBlue;
            this.inputCustomerNumber.BorderThickness = 3;
            this.inputCustomerNumber.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.inputCustomerNumber.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.inputCustomerNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.inputCustomerNumber.isPassword = false;
            this.inputCustomerNumber.Location = new System.Drawing.Point(356, 77);
            this.inputCustomerNumber.Margin = new System.Windows.Forms.Padding(4);
            this.inputCustomerNumber.Name = "inputCustomerNumber";
            this.inputCustomerNumber.Size = new System.Drawing.Size(280, 44);
            this.inputCustomerNumber.TabIndex = 24;
            this.inputCustomerNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // c
            // 
            this.c.AutoSize = true;
            this.c.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.c.Location = new System.Drawing.Point(60, 20);
            this.c.Name = "c";
            this.c.Size = new System.Drawing.Size(166, 37);
            this.c.TabIndex = 22;
            this.c.Text = "Feedback ";
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(531, 324);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(65, 45);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton1.TabIndex = 29;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            this.bunifuImageButton1.Click += new System.EventHandler(this.bunifuImageButton1_Click);
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "Add to object";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton1.Iconimage")));
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(141, 831);
            this.bunifuFlatButton1.Margin = new System.Windows.Forms.Padding(6);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(442, 89);
            this.bunifuFlatButton1.TabIndex = 30;
            this.bunifuFlatButton1.Text = "Add to object";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabControl1.Location = new System.Drawing.Point(77, 218);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(510, 100);
            this.tabControl1.TabIndex = 35;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(118)))), ((int)(((byte)(106)))), ((int)(((byte)(255)))));
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.excellent1);
            this.tabPage1.Controls.Add(this.good1);
            this.tabPage1.Controls.Add(this.av1);
            this.tabPage1.Controls.Add(this.dis1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(502, 74);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Food";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(431, 52);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 40;
            this.button2.Text = "Next 1";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // excellent1
            // 
            this.excellent1.AutoSize = true;
            this.excellent1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.excellent1.Location = new System.Drawing.Point(383, 29);
            this.excellent1.Name = "excellent1";
            this.excellent1.Size = new System.Drawing.Size(75, 19);
            this.excellent1.TabIndex = 38;
            this.excellent1.Text = "Excellent";
            this.excellent1.UseVisualStyleBackColor = true;
            // 
            // good1
            // 
            this.good1.AutoSize = true;
            this.good1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.good1.Location = new System.Drawing.Point(265, 29);
            this.good1.Name = "good1";
            this.good1.Size = new System.Drawing.Size(55, 19);
            this.good1.TabIndex = 37;
            this.good1.Text = "Good";
            this.good1.UseVisualStyleBackColor = true;
            // 
            // av1
            // 
            this.av1.AutoSize = true;
            this.av1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.av1.Location = new System.Drawing.Point(142, 29);
            this.av1.Name = "av1";
            this.av1.Size = new System.Drawing.Size(69, 19);
            this.av1.TabIndex = 36;
            this.av1.Text = "Average";
            this.av1.UseVisualStyleBackColor = true;
            // 
            // dis1
            // 
            this.dis1.AutoSize = true;
            this.dis1.Checked = true;
            this.dis1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dis1.Location = new System.Drawing.Point(38, 29);
            this.dis1.Name = "dis1";
            this.dis1.Size = new System.Drawing.Size(88, 19);
            this.dis1.TabIndex = 35;
            this.dis1.TabStop = true;
            this.dis1.Text = "Dissatisfied";
            this.dis1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(154)))), ((int)(((byte)(141)))), ((int)(((byte)(255)))));
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.excellent2);
            this.tabPage2.Controls.Add(this.good2);
            this.tabPage2.Controls.Add(this.average2);
            this.tabPage2.Controls.Add(this.dis2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(502, 74);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Services";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(431, 52);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 39;
            this.button1.Text = "Next 2";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // excellent2
            // 
            this.excellent2.AutoSize = true;
            this.excellent2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.excellent2.Location = new System.Drawing.Point(383, 29);
            this.excellent2.Name = "excellent2";
            this.excellent2.Size = new System.Drawing.Size(75, 19);
            this.excellent2.TabIndex = 38;
            this.excellent2.TabStop = true;
            this.excellent2.Text = "Excellent";
            this.excellent2.UseVisualStyleBackColor = true;
            // 
            // good2
            // 
            this.good2.AutoSize = true;
            this.good2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.good2.Location = new System.Drawing.Point(265, 29);
            this.good2.Name = "good2";
            this.good2.Size = new System.Drawing.Size(55, 19);
            this.good2.TabIndex = 37;
            this.good2.TabStop = true;
            this.good2.Text = "Good";
            this.good2.UseVisualStyleBackColor = true;
            // 
            // average2
            // 
            this.average2.AutoSize = true;
            this.average2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.average2.Location = new System.Drawing.Point(142, 29);
            this.average2.Name = "average2";
            this.average2.Size = new System.Drawing.Size(69, 19);
            this.average2.TabIndex = 36;
            this.average2.TabStop = true;
            this.average2.Text = "Average";
            this.average2.UseVisualStyleBackColor = true;
            // 
            // dis2
            // 
            this.dis2.AutoSize = true;
            this.dis2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dis2.Location = new System.Drawing.Point(38, 29);
            this.dis2.Name = "dis2";
            this.dis2.Size = new System.Drawing.Size(92, 19);
            this.dis2.TabIndex = 35;
            this.dis2.TabStop = true;
            this.dis2.Text = "Dis-satisfied";
            this.dis2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(95)))), ((int)(((byte)(75)))), ((int)(((byte)(139)))), ((int)(((byte)(255)))));
            this.tabPage3.Controls.Add(this.button3);
            this.tabPage3.Controls.Add(this.excellent3);
            this.tabPage3.Controls.Add(this.good3);
            this.tabPage3.Controls.Add(this.satisfied3);
            this.tabPage3.Controls.Add(this.dis3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(502, 74);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Hospitality";
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(431, 55);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 4;
            this.button3.Text = "Submit";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // excellent3
            // 
            this.excellent3.AutoSize = true;
            this.excellent3.BackColor = System.Drawing.Color.Transparent;
            this.excellent3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.excellent3.Location = new System.Drawing.Point(355, 29);
            this.excellent3.Name = "excellent3";
            this.excellent3.Size = new System.Drawing.Size(75, 19);
            this.excellent3.TabIndex = 3;
            this.excellent3.TabStop = true;
            this.excellent3.Text = "Excellent";
            this.excellent3.UseVisualStyleBackColor = false;
            // 
            // good3
            // 
            this.good3.AutoSize = true;
            this.good3.BackColor = System.Drawing.Color.Transparent;
            this.good3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.good3.Location = new System.Drawing.Point(264, 29);
            this.good3.Name = "good3";
            this.good3.Size = new System.Drawing.Size(55, 19);
            this.good3.TabIndex = 2;
            this.good3.TabStop = true;
            this.good3.Text = "Good";
            this.good3.UseVisualStyleBackColor = false;
            this.good3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // satisfied3
            // 
            this.satisfied3.AutoSize = true;
            this.satisfied3.BackColor = System.Drawing.Color.Transparent;
            this.satisfied3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.satisfied3.Location = new System.Drawing.Point(152, 29);
            this.satisfied3.Name = "satisfied3";
            this.satisfied3.Size = new System.Drawing.Size(69, 19);
            this.satisfied3.TabIndex = 1;
            this.satisfied3.TabStop = true;
            this.satisfied3.Text = "Average";
            this.satisfied3.UseVisualStyleBackColor = false;
            // 
            // dis3
            // 
            this.dis3.AutoSize = true;
            this.dis3.BackColor = System.Drawing.Color.Transparent;
            this.dis3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dis3.Location = new System.Drawing.Point(60, 29);
            this.dis3.Name = "dis3";
            this.dis3.Size = new System.Drawing.Size(92, 19);
            this.dis3.TabIndex = 0;
            this.dis3.TabStop = true;
            this.dis3.Text = "Dis-satisfied";
            this.dis3.UseVisualStyleBackColor = false;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(114)))), ((int)(((byte)(139)))));
            this.ClientSize = new System.Drawing.Size(652, 376);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.bunifuFlatButton1);
            this.Controls.Add(this.bunifuImageButton1);
            this.Controls.Add(this.bunifuFlatButton2);
            this.Controls.Add(this.inputCustomerAddress);
            this.Controls.Add(this.inputCustomerName);
            this.Controls.Add(this.inputCustomerEmail);
            this.Controls.Add(this.inputCustomerNumber);
            this.Controls.Add(this.c);
            this.Controls.Add(this.bunifuCustomLabel2);
            this.Name = "Form4";
            this.ShowIcon = false;
            this.Text = "Feedback";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private ns1.BunifuCustomLabel bunifuCustomLabel2;
        private ns1.BunifuFlatButton bunifuFlatButton2;
        private ns1.BunifuMetroTextbox inputCustomerAddress;
        private ns1.BunifuMetroTextbox inputCustomerName;
        private ns1.BunifuMetroTextbox inputCustomerEmail;
        private ns1.BunifuMetroTextbox inputCustomerNumber;
        private ns1.BunifuCustomLabel c;
        private ns1.BunifuImageButton bunifuImageButton1;
        private ns1.BunifuFlatButton bunifuFlatButton1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.RadioButton excellent1;
        private System.Windows.Forms.RadioButton good1;
        private System.Windows.Forms.RadioButton av1;
        private System.Windows.Forms.RadioButton dis1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.RadioButton excellent2;
        private System.Windows.Forms.RadioButton good2;
        private System.Windows.Forms.RadioButton average2;
        private System.Windows.Forms.RadioButton dis2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.RadioButton good3;
        private System.Windows.Forms.RadioButton satisfied3;
        private System.Windows.Forms.RadioButton dis3;
        private System.Windows.Forms.RadioButton excellent3;
        private System.Windows.Forms.Button button3;
    }
}